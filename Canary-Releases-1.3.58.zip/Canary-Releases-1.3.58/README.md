# Canary Release Channel

Builds of my [Ryujinx fork](https://ryujinx.app) compiled &amp; released after every commit to the repository.

This is mostly for advanced users; regular users should stick to the regular stable releases. You can find those [here](https://github.com/Ryubing/Stable-Releases).
